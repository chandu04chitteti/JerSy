package com.cts.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.persistence.Book;
import com.cts.persistence.Department;
import com.cts.persistence.Employee;



@Repository("empMysqlDao")
public class MysqlEmployeeDaoImpl implements MySqlEmployeeDao{
	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	@Transactional
	public Employee findById(long id) {
		Employee employee = (Employee) sessionFactory.getCurrentSession().get(Employee.class, id);
		return employee;
	}

	@Override
	@Transactional
	public String saveEmployee(Employee employee) {
		long employeeId = (long) sessionFactory.getCurrentSession().save(employee);
		return "employee information saved successfully with empID " + employeeId;
		
	}

	@Override
	@Transactional
	public String updateEmployee(Employee employee) {
		sessionFactory.getCurrentSession().update(employee);
		return "Employee information updated successfully";
		
	}

	@Override
	@Transactional
	public String deleteEmployeeById(Employee employee) {
		
		
		sessionFactory.getCurrentSession().delete(employee);
		return "Employee information with ID " + employee.getEmployeeId() +  " deleted successfully";
	}

	@Override
	@Transactional
	public List<Employee> findAllEmployees() {
		System.out.println("findAllEmployees in Dao impl");
		List<Employee> lstBook = sessionFactory.getCurrentSession().createCriteria(Employee.class).list();
		System.out.println("findAllEmployees size "+lstBook.size());
		return lstBook;
	}

	@Override
	@Transactional
	public List<Department> findAllDepartments(){
		System.out.println("findAllDepartments");
	List<Department> listDepartments = sessionFactory.getCurrentSession().createCriteria(Department.class).list();
	System.out.println("listDepartments size "+listDepartments.size());
	return listDepartments;
}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Book> getAllBookInfo() {
		System.out.println("getAllBookInfo in Dao Impl =====>");
		// get all books info from database
		List<Book> lstBook = sessionFactory.getCurrentSession().createCriteria(Book.class).list();
		System.out.println("lstBook size is "+lstBook.size());
		return lstBook;
	}
	
}


