package com.cts.dao;


import java.util.List;

import com.cts.persistence.Book;
import com.cts.persistence.Department;
import com.cts.persistence.Employee;

public interface MySqlEmployeeDao {
	
	Employee findById(long id);	
	
	String saveEmployee(Employee employee);
	
	String updateEmployee(Employee employee);
	
	String deleteEmployeeById(Employee employee);

	List<Employee> findAllEmployees();
	
	List<Department> findAllDepartments();
	List<Book> getAllBookInfo();
	
	
	
	
}
