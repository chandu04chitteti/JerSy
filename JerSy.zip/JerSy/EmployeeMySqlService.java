package com.cts.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.dao.MySqlEmployeeDao;
import com.cts.model.Dept;
import com.cts.model.Emp;
import com.cts.persistence.Book;
import com.cts.persistence.Department;
import com.cts.persistence.Employee;


@Component
@Path("/empMySqlService")
public class EmployeeMySqlService {


	
@Autowired
private MySqlEmployeeDao  empMysqlDao;
	
	@GET
	@Path(value = "getMySqlRequest")
	@Produces("text/html")
	public Response process() {
		System.out.println("Amma Bhagavan Sharanum");
		String output = "Amma Bhagavan Sharanum";
		return Response.status(200).entity(output).build();
	}
	
	
	@GET
	@Path("getMySqlEmployee")
	@Produces({MediaType.APPLICATION_JSON})
	public Emp getEmpInfo(@HeaderParam("empId")  int empId) {

		// retrieve book information based on the id supplied in the formal argument
		Employee employee = empMysqlDao.findById(empId);
		Emp emp = new Emp(); 
		emp.setEmployeeId(employee.getEmployeeId());
		emp.setFirstname(employee.getFirstname());
		emp.setLastname(employee.getLastname());
		emp.setBirthDate(employee.getBirthDate());
		emp.setCellphone(employee.getCellphone());
		return emp;
	}
	
		
	
	// http://localhost:8080/Jersey-Spring-Hibernate/rest/bookservice/addbook
	
	
		@POST
		@Path("addMySqlEmployee")
		//@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
		@Produces("text/html")
		public String createOrSaveEmployee( @HeaderParam("firstName") String firstname, 
				@HeaderParam("lastName") String lastname,
                @HeaderParam("birthDate") String birthDate,
                @HeaderParam("cellphone") String cellphone )
                {

			Employee  employee = new Employee();
			employee.setFirstname(firstname);
			employee.setLastname(lastname);
			employee.setBirthDate(Date.valueOf(birthDate));
			employee.setCellphone(cellphone);
			empMysqlDao.saveEmployee(employee);
			
			return "EmployeeAdded";
		}
	
		@GET
		@Path("getAllMySqlemployees")
		@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
		public List<Emp> getEmployeeInfo() {
			List<Employee> emps = empMysqlDao.findAllEmployees();
			
			List<Emp> empList = new ArrayList<Emp> ();
			
			for(Employee employee:  emps){
				Emp emp = new Emp(); 
				emp.setEmployeeId(employee.getEmployeeId());
				emp.setFirstname(employee.getFirstname());
				emp.setLastname(employee.getLastname());
				emp.setBirthDate(employee.getBirthDate());
				emp.setCellphone(employee.getCellphone());
				empList.add(emp);
			}
			return empList;
			
		}
		
		@GET
		@Path("getAllDepartments")
		@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
		public List<Dept> getDeptInfo() {
			List<Department> departments = empMysqlDao.findAllDepartments();
			
			List<Dept> depts = new ArrayList<Dept> ();			
			for (Department department: departments){
				Dept dept = new Dept();
				dept.setDepartmentId(department.getDepartmentId());	
				dept.setDepartmentName(department.getDepartmentName());
				depts.add(dept);
			}
			
			return depts;
			
		}
		
		@PUT
		@Path("updateMySqlEmployee")
		//@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
		//@Produces(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces("text/html")
		public String updateEmployee(
				@HeaderParam("empId")  int empId,
				@HeaderParam("firstName") String firstName, 
				@HeaderParam("lastName") String lastname,
                @HeaderParam("birthDate") String birthDate,
                @HeaderParam("cellphone") String cellphone )
                {
			Employee presentemployee = empMysqlDao.findById(empId);
			
			presentemployee.setFirstname(firstName);
			//SimpleDateFormat formatter2=new SimpleDateFormat("dd-MMM-yyyy");
			
			
			presentemployee.setBirthDate(Date.valueOf(birthDate));
			presentemployee.setCellphone(cellphone);
			presentemployee.setLastname(lastname);

			// update book info & return SUCCESS message
			String result = empMysqlDao.updateEmployee(presentemployee);
			 
			 return result;
		}
	
		
		@DELETE
		@Path("deleteMySqlEmployee")
		//@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		//@Produces(MediaType.APPLICATION_FORM_URLENCODED)
		public String deleteEmployee(@HeaderParam("empId")  long empId) {
			Employee presentemployee = new Employee ();
			presentemployee.setEmployeeId(empId);
			String result = empMysqlDao.deleteEmployeeById(presentemployee);			
			return result;
			
		}
		
	
		@GET
		@Path("getAllBooks")
		@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
		public List<Book> getAllBookInfo() {
			List<Book> depts = empMysqlDao.getAllBookInfo();			
			return depts;
			
		}
	
	
	
}